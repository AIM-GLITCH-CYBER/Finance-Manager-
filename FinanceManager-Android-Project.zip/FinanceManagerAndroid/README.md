# Finance Manager — Android APK-ready project

This is an Android Studio/Gradle project wrapping the Finance Manager HTML app in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app`.
4. Build > Build APK(s).
5. Install the generated APK on your Android phone.

The HTML app is bundled at `app/src/main/assets/index.html`.

The app requires Internet permission because the Finance Manager uses Supabase.

Important:
- The Supabase publishable key may be embedded in the client app.
- Never put a Supabase service-role/secret key or Mono secret key in this Android project.
- Mono/OPay bank linking should continue through the secure Edge Functions/backend.
